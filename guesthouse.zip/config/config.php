<?php

// This is the brain of the app, all the global settings in one place.
// If there needs to be a change in password or site name, it can only be changed here.

// config/config.php
// Global configuration - DB credentials + site settings
// Edit this file when deploying to a live server

// DATABASE SETTINGS

// define('DB_HOST', 'localhost'); // XAMPP default
// define('DB_USER', 'root'); // XAMPP default username
// define('DB_PASS', ''); // XAMPP default = no password
// define('DB_NAME', 'guesthouse'); // DB will created later on.

define('DB_HOST', 'sql.infinityfree.com'); // they give you this
define('DB_USER', 'if0_41693830');
define('DB_PASS', 'Bu4BVwRY6UkiQHt');
define('DB_NAME', 'if0_41693830_guesthouse_database');
define('SITE_URL', 'https://yvessaintoryanguesthouse.infinityfree.me/?i=1');

// Site Settings
define('SITE_NAME', 'The Grand Guesthouse');
define('SITE_EMAIL', 'info@grandguesthouse.com');
define('SITE_PHONE', '+27 12 345 6789');
// define('SITE_URL', 'http://localhost/guesthouse');


// Security
define('SECRET_KEY', 'change-this-to-a-random-string-in-production');

// Paths
define('ROOT_PATH', dirname(__DIR__)); // Project root
define('PUBLIC_PATH', ROOT_PATH. '/public');
define('UPLOAD_PATH', PUBLIC_PATH . '/assets/images/uploads');
?>